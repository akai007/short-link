export default {
    port: process.env.SERVER_PORT || 3000,
    timeout: process.env.SERVER_TIMEOUT || 5000,
};
