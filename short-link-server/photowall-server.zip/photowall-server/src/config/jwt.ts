export default {
    secret: process.env.JWT_SECRET,
    options: {
        jwtid: process.env.JWT_ID,
        algorithm: process.env.JWT_ALGORITHM,
        expiresIn: process.env.JWT_EXPIRESIN,
    },
};
