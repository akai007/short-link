export default {
    type: 'mysql',
    host: process.env.DB_HOST,
    username: process.env.DB_USERNAME,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    // tslint:disable-next-line:radix
    port: parseInt(process.env.DB_PORT),

    synchronize: true,
    entities: [
        'src/**/**.entity{.ts,.js}',
    ],
    subscribers: [
        'src/domain/subscriber/*.js',
    ],
    migrations: [
        'src/domain/migration/*.js',
    ],
    cli: {
        entitiesDir: 'src/entity',
        migrationsDir: 'src/domain/migration',
        subscribersDir: 'src/domain/subscriber',
    },
};
