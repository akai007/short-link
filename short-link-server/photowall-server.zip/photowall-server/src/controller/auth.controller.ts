import { Body, Controller, Post } from '@nestjs/common';
import { User } from 'src/entity/user.entity';
import { AuthService } from 'src/service/auth.service';
import { UserService } from 'src/service/user.service';
import * as _ from 'lodash';

@Controller()
export class AuthController {
    constructor(
        private authService: AuthService,
        private userService: UserService,
    ) { }

    @Post('/login')
    public async login(@Body() user: User) {

        const token = await this.authService.sign(user);

        return 'Bearer ' + token;
    }

    @Post('/register')
    async register(@Body() user: User) {

        user = await this.userService.create(user);

        return _.omit(user, ['id', 'password']);

    }

}
