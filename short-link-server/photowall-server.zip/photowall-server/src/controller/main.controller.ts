import { Controller, Get } from '@nestjs/common';
import { UserService } from 'src/service/user.service';
import { User } from 'src/entity/user.entity';

@Controller()
export class MainController {
    constructor(private readonly userService: UserService) { }

    @Get('/hello-world')
    async helloWorld() {
        return 'Hello World!';
    }

    @Get('/')
    findAll(): Promise<User[]> {
        return this.userService.findAll();
    }
}
