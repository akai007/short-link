import * as _ from 'lodash';
import { Controller, Get, Post, Body } from '@nestjs/common';
import { UserService } from 'src/service/user.service';
import { User } from 'src/entity/user.entity';
import { ValidationError, validate } from 'class-validator';

@Controller()
export class UserController {
    constructor(private readonly userService: UserService) { }

    @Get('/users')
    findAll(): Promise<User[]> {
        return this.userService.findAll();
    }

    @Post('/users')
    public async post(@Body() user: User) {
        const errors: ValidationError[] = await validate(user); // errors is an array of validation errors

        if (errors.length > 0) {
            throw errors;
        } else {
            user = await this.userService.create(user);
            return _.omit(user, ['id', 'password']);
        }
    }
}
