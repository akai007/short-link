
export class EnumDto {
    constructor(
        public code: number,
        public msg: string,
    ) { }
}
