export interface BaseInterceptorInterface {
    before(): void;
    after(): void;
}
