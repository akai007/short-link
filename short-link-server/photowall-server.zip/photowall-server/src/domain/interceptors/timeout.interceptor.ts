import { Injectable, NestInterceptor, ExecutionContext } from '@nestjs/common';
import { Observable } from 'rxjs';
import { timeout } from 'rxjs/operators';

@Injectable()
export class TimeoutInterceptor implements NestInterceptor {
    constructor(
        protected duration,
    ) { }
    intercept(
        context: ExecutionContext,
        call$: Observable<any>,
    ): Observable<any> {
        return call$.pipe(timeout(this.duration));
    }
}
