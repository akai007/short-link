
import { Injectable, NestInterceptor, ExecutionContext } from '@nestjs/common';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ResponseResult } from '../dto/response-result.dto';
import { CodeEnum, CodeEnumMap } from '../enum/code.enum';

@Injectable()
export class TransformInterceptor<T>
    implements NestInterceptor<T, ResponseResult<T>> {
    intercept(
        context: ExecutionContext,
        call$: Observable<T>,
    ): Observable<ResponseResult<T>> {
        return call$.pipe(map( data => {
            return new ResponseResult<T>(
                CodeEnum.SUCCESS,
                CodeEnumMap.get(CodeEnum.SUCCESS),
                data,
            );
        }));
    }
}
