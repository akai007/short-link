import * as jwt from 'jsonwebtoken';
import { Injectable, NestMiddleware, HttpException, MiddlewareFunction } from '@nestjs/common';
import { User } from 'src/entity/user.entity';
import { ForbiddenException } from 'src/domain/exception/forbidden.exception';
import { InjectConfig } from 'nestjs-config';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { UserService } from 'src/service/user.service';

@Injectable()
export class AuthMiddleware implements NestMiddleware {
    constructor(
        @InjectConfig() private readonly config,
        @InjectRepository(User) private readonly userRepository: Repository<User>,
    ) { }

    public resolve(...args: any[]): MiddlewareFunction {
        return async (req, res, next) => {
            // exclude list
            if ( false
                || req.baseUrl === '/login'
                || req.baseUrl === '/register'
            ) {
                next();
                return;
            }

            if (req.headers.authorization && (req.headers.authorization as string).split(' ')[0] === 'Bearer') {
                const token = (req.headers.authorization as string).split(' ')[1];
                const queryUser: User = jwt.verify(token, this.config.get('jwt.secret'));
                const user: User = await this.userRepository.findOne(queryUser);
                if (!user) {
                    throw new ForbiddenException();
                }
                next();
            } else {
                throw new ForbiddenException();
            }
        };
    }
}
