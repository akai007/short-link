import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, DefaultNamingStrategy } from 'typeorm';
import { Length, IsEmail, IsPhoneNumber, IsMobilePhone, IsDefined } from 'class-validator';
import { BaseEntity } from './base.entity';

@Entity()
export class Wall extends BaseEntity {

    @PrimaryGeneratedColumn()
    id: number;

    @Column({ name: 'title', type: 'varchar', width: 100, comment: '标题' })
    title: string;

    @Column({ name: 'desc', type: 'varchar', width: 200, comment: '描述' })
    desc: string;

    // 墙尺寸
    @Column({ name: 'width', type: 'int', width: 20, default: 0, comment: '墙宽度' })
    width: number;

    @Column({ name: 'height', type: 'int', width: 20, default: 0, comment: '墙高度' })
    height: number;

    @Column({ name: 'photo_count', type: 'int', width: 10, default: 0, comment: '照片个数' })
    photoCount: number;

}
