import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { join } from 'path';
import { HttpExceptionFilter } from './domain/exception-filter/http-exception.filter';
import { ValidationPipe } from './domain/pipe/validation.pipe';
import { TypeormExceptionFilter } from './domain/exception-filter/typeorm-exception.filter';
import { LoggingInterceptor } from './domain/interceptors/logging.interceptor';
import { TimeoutInterceptor } from './domain/interceptors/timeout.interceptor';
import { TransformInterceptor } from './domain/interceptors/transform.interceptor';

async function bootstrap() {
    const app = await NestFactory.create(AppModule);
    app.enableCors({
        origin: 'http://localhost:8080',
        methods: ['GET', 'PUT', 'POST', 'DELETE'],
        allowedHeaders: ['authorization', 'content-type', 'x-admin-token'],
    })
    // app.enableCors();

    //        |<----------------------------|                 |
    // client | middleware -> guard -> interceptor -> pipe -> | controller
    //        |                             |---------------> |

    // rigister exception filters
    app.useGlobalFilters(new HttpExceptionFilter());
    app.useGlobalFilters(new TypeormExceptionFilter());

    // Interceptor
    app.useGlobalInterceptors(new LoggingInterceptor());
    app.useGlobalInterceptors(new TimeoutInterceptor(require('./config/base').default.timeout));
    app.useGlobalInterceptors(new TransformInterceptor() );

    // ValidationPipe
    app.useGlobalPipes(new ValidationPipe());

    // static folder
    app.useStaticAssets(join(__dirname, '..', 'public'));
    // app.setBaseViewsDir(join(__dirname, '..', 'views'));
    // app.setViewEngine('hbs');

    await app.listen(require('./config/base').default.port);
}

bootstrap();
