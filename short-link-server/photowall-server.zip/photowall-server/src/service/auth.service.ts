import * as _ from 'lodash';
import * as jwt from 'jsonwebtoken';
import { Injectable, HttpException, HttpStatus } from '@nestjs/common';
import { IAuthService, IJwtOptions } from './auth.service.interface';
import { User } from 'src/entity/user.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { InjectConfig } from 'nestjs-config';
import { BaseUtils } from 'src/utils/BaseUtils';
import { BaseException } from 'src/domain/exception/base.exception';
import { CodeEnum } from 'src/domain/enum/code.enum';
import { ResponseResult } from 'src/domain/dto/response-result.dto';

@Injectable()
export class AuthService implements IAuthService {
    constructor(
        @InjectConfig() private readonly config,
        @InjectRepository(User) private readonly userRepository: Repository<User>,
    ) {}

    public options: IJwtOptions = this.config.get('jwt.options');
    public secret: string = this.config.get('jwt.secret');

    public async sign(user: User): Promise<string> {
        user.password = BaseUtils.encryptPWD(user.password); // encrypt password
        user = await this.userRepository.findOne(user);

        if (!user) {
            throw new BaseException(new ResponseResult(CodeEnum.FAIL, 'username or password wrong', {}) , HttpStatus.OK);
        }

        const payload: any = _.pick(user, ['id', 'nickname', 'phone']);

        return await jwt.sign(payload, this.secret || '', this.options);
    }
}
