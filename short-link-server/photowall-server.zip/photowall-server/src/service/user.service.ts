import { Injectable, HttpException, HttpStatus } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { User } from 'src/entity/user.entity';
import { Repository } from 'typeorm';
import { BaseUtils } from 'src/utils/BaseUtils';

@Injectable()
export class UserService {
    constructor(@InjectRepository(User) private readonly userRepository: Repository<User>) { }

    async findAll(): Promise<User[]> {
        return await this.userRepository.find();
    }

    async findOne(user: User): Promise<User> {
        return await this.userRepository.findOne(user);
    }

    async create(user: User): Promise<User> {
        user.password = BaseUtils.encryptPWD(user.password); // encrypt password

        if (await this.userRepository.findOne({ email: user.email })) {
            // return BAD REQUEST status code and email already exists error
            throw new HttpException('email is already exist', HttpStatus.INTERNAL_SERVER_ERROR);
        } else {
            // save the user contained in the POST body
            user = await this.userRepository.save(user);
            // return CREATED status code and updated user
            return user;
        }
    }

}
