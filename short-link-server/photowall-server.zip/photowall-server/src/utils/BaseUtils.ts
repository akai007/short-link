import * as crypto from 'crypto';

export class BaseUtils {
    public static encryptPWD(password): string {
        return crypto.createHmac('sha256', password).digest('hex');
    }
}
