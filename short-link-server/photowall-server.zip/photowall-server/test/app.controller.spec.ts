import { Test, TestingModule } from '@nestjs/testing';
import { MainController } from '../src/controller/main.controller';

describe('AppController', () => {
  let app: TestingModule;

  beforeAll(async () => {
    app = await Test.createTestingModule({
      controllers: [MainController],
      providers: [],
    }).compile();
  });

  describe('root', () => {
    it('should return "Hello World!"', () => {
      const appController = app.get<MainController>(MainController);
      expect(appController.helloWorld()).toBe('Hello World!');
    });
  });
});
